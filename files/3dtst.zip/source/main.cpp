#include <cstdio>
#include <nds.h>

int main()
{
    videoSetMode(MODE_0_3D);
    vramSetBankA(VRAM_A_TEXTURE);
	consoleDemoInit();

    glInit();
    glViewport(0, 0, 255, 191);
    glClearColor(3, 3, 3, 31);
    glClearDepth(0x7FFF);
    glClearPolyID(63);
    glSetOutlineColor(0, 0x7E00);
    glEnable(GL_BLEND);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 3, 3, 0, -10, 10);

    glMatrixMode(GL_POSITION);
    glLoadIdentity();

    uint16_t texture[128 * 128];
    for (int y = 0; y < 128; y++)
        for (int x = 0; x < 128; x++)
            texture[y * 128 + x] = (x % 2) ? 0xFFFF : 0xABCD;

    int textureID;
    glEnable(GL_TEXTURE_2D);
    glGenTextures(1, &textureID);
    glBindTexture(0, textureID);
    glTexImage2D(0, 0, GL_RGB, TEXTURE_SIZE_128, TEXTURE_SIZE_128, 0, TEXGEN_TEXCOORD, texture);

    int x[4], y[4];
    x[0] =  64; y[0] =  32; x[1] =  64; y[1] = 160;
    x[2] = 192; y[2] = 160; x[3] = 192; y[3] =  32;
    int vertex = 0;
    bool antiAlias = false, edgeMark = false;
    bool trans = false, wire = false;
    uint16_t held = 0;

    bool fine = false;

    while (true)
    {
        printf("x1=%d, y1=%d, x2=%d, y2=%d\n", x[0], y[0], x[1], y[1]);
        printf("x3=%d, y3=%d, x4=%d, y4=%d\n", x[2], y[2], x[3], y[3]);
        printf("\n");
        printf("Current vertex: %d\n", vertex + 1);
        printf("\n");
        printf("Anti-aliasing: %s\n", antiAlias ? "on" : "off");
        printf("Edge marking: %s\n", edgeMark ? "on" : "off");
        printf("Transparency: %s\n", trans ? "on" : "off");
        printf("Wireframe: %s\n", wire ? "on" : "off");
        printf("\n");
        printf("ABXY to select vertex 1234\n");
        printf("Dpad to move selected vertex\n");
        printf("L to toggle anti-aliasing\n");
        printf("R to toggle edge marking\n");
        printf("Start to toggle transparency\n");
        printf("Select to toggle wireframe\n");
        printf("Start+select to exit\n");

        scanKeys();
        uint16_t keys = keysHeld();

        if (keys & KEY_A) vertex = 0;
        if (keys & KEY_B) vertex = 1;
        if (keys & KEY_X) vertex = 2;
        if (keys & KEY_Y) vertex = 3;

        if (!fine)
        {
            if (keys & KEY_UP)    y[vertex]--;
            if (keys & KEY_DOWN)  y[vertex]++;
            if (keys & KEY_LEFT)  x[vertex]--;
            if (keys & KEY_RIGHT) x[vertex]++;
        }

        fine = (keys & (KEY_A | KEY_B | KEY_X | KEY_Y)) && (keys & (KEY_UP | KEY_DOWN | KEY_LEFT | KEY_RIGHT));

        if (keys & KEY_L)
        {
            if (!(held & KEY_L))
                antiAlias = !antiAlias;
            held |= KEY_L;
        }
        else
        {
            held &= ~KEY_L;
        }

        if (keys & KEY_R)
        {
            if (!(held & KEY_R))
                edgeMark = !edgeMark;
            held |= KEY_R;
        }
        else
        {
            held &= ~KEY_R;
        }

        if (keys & KEY_START)
        {
            if (!(held & KEY_START))
                trans = !trans;
            held |= KEY_START;
        }
        else
        {
            held &= ~KEY_START;
        }

        if (keys & KEY_SELECT)
        {
            if (!(held & KEY_SELECT))
                wire = !wire;
            held |= KEY_SELECT;
        }
        else
        {
            held &= ~KEY_SELECT;
        }

        if ((keys & KEY_START) && (keys & KEY_SELECT)) break;

        antiAlias ? glEnable(GL_ANTIALIAS) : glDisable(GL_ANTIALIAS);
        edgeMark ? glEnable(GL_OUTLINE) : glDisable(GL_OUTLINE);
        glPolyFmt(POLY_ALPHA(wire ? 0 : (trans ? 25 : 31)) | POLY_CULL_NONE);

        glBegin(GL_QUAD);
        glColor3b(255, 255, 255);

        GFX_TEX_COORD = TEXTURE_PACK(inttot16(0), inttot16(0));
        glVertex3v16(x[0] * 48, y[0] * 64, 0);

        GFX_TEX_COORD = TEXTURE_PACK(inttot16(0), inttot16(128));
        glVertex3v16(x[1] * 48, y[1] * 64, 0);

        GFX_TEX_COORD = TEXTURE_PACK(inttot16(128), inttot16(128));
        glVertex3v16(x[2] * 48, y[2] * 64, 0);

        GFX_TEX_COORD = TEXTURE_PACK(inttot16(128), inttot16(0));
        glVertex3v16(x[3] * 48, y[3] * 64, 0);

        glEnd();
        glFlush(0);
        swiWaitForVBlank();
        consoleClear();
    }

    return 0;
}
